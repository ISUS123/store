let register = document.querySelector("form");

register.addEventListener('submit', function (evt) {
    evt.preventDefault();
    console.log("reg");
});


