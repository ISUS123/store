let content = document.querySelector("content .container");
let basePath = "assets/pages/";
let pages = document.querySelectorAll(".page-link"); 

let getPage = function(page) {
    let xhr = new XMLHttpRequest()
    xhr.open('GET', basePath + page)
    xhr.onload = function () {
        content.innerHTML = xhr.response
    }
    xhr.send();
};

for(let i = 0; i < pages.length; i++) {
    pages[i].addEventListener('click', function(evt) {
        evt.preventDefault();
        getPage(pages[i].dataset.page + '.html');
    });
}

getPage('register.html');


